import Testing
@testable import DayGlyph

@MainActor
struct AppleIntelligenceStatusTests {
    @Test func availableStatusCanUseFoundationModels() {
        let status = AppleIntelligenceStatus.available

        #expect(status.canUseFoundationModels)
        #expect(status.title == "Apple Intelligence 已就绪")
    }

    @Test func deviceNotEligibleExplainsGenerationIsUnavailable() {
        let status = AppleIntelligenceStatus.deviceNotEligible

        #expect(status.canUseFoundationModels == false)
        #expect(status.title == "此设备不符合运行条件")
        #expect(status.detail.contains("无法生成"))
        #expect(status.detail.contains("本地分析") == false)
    }

    @Test func modelNotReadyDoesNotClaimAvailability() {
        let status = AppleIntelligenceStatus.modelNotReady

        #expect(status.canUseFoundationModels == false)
        #expect(status.detail.contains("准备"))
    }

    @Test func statusProvidesActionableSuggestion() {
        #expect(AppleIntelligenceStatus.appleIntelligenceNotEnabled.suggestion.contains("系统设置"))
        #expect(AppleIntelligenceStatus.deviceNotEligible.suggestion.contains("符合条件"))
    }

#if targetEnvironment(simulator)
    @Test func simulatorExplainsThatAppleIntelligenceCannotBeEnabledSeparately() {
        let status = AppleIntelligenceStatus.appleIntelligenceNotEnabled

        #expect(status.suggestion.contains("模拟器无法单独开启"))
        #expect(status.suggestion.contains("宿主 Mac"))
    }
#endif
}
