import Foundation

/// 比赛提交包中的安全占位配置。
/// 如需启用在线生成，请在本地替换为自己的火山方舟 ARK API Key。
enum AISecrets {
    static let arkAPIKey = "PUT_YOUR_ARK_API_KEY_HERE"
}
